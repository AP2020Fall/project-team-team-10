import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Controller extends Application {

    public static boolean isCyanTurn = true;
    public static int cyanScore = 0;
    public static int magentaScore = 0;
    boolean startGame = false;

    public static void saveHistory() {
        try {
            File myObj = new File("filename.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            try {
                FileWriter myWriter = new FileWriter("filename.txt");
                String output = "Magenta : " + magentaScore + "| Cyan :" + cyanScore;
                myWriter.write(output);
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Dots & Boxes");

        int buttonWidth = 64;
        int buttonHeight = 16;

        Rectangle[][] squares = new Rectangle[7][7];
        Button[][] horizontalButtons = new Button[7][8];
        Button[][] verticalButtons = new Button[8][7];
        Group group = new Group();

        Button startButton = new Button("Start");

        Text text = new Text("It's " + (isCyanTurn ? "Cyan" : "Magenta") + " turn");
        Text cyanScoreText = new Text("Cyan : " + cyanScore);
        Text magentaScoreText = new Text("Magenta : " + magentaScore);

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                squares[i][j] = new Rectangle();
                squares[i][j] = new Rectangle();
                squares[i][j].getStyleClass().add("white");
                squares[i][j].setWidth(buttonWidth);
                squares[i][j].setHeight(buttonWidth);
                squares[i][j].setLayoutX(buttonHeight + i * buttonWidth + i * buttonHeight);
                squares[i][j].setLayoutY(buttonHeight + j * buttonWidth + j * buttonHeight);

                group.getChildren().add(squares[i][j]);
            }
        }

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 8; j++) {
                horizontalButtons[i][j] = new Button();

                horizontalButtons[i][j].setPadding(new Insets(0));

                horizontalButtons[i][j].setPrefSize(buttonWidth, buttonHeight);

                horizontalButtons[i][j].setLayoutX(i * buttonWidth + i * buttonHeight + buttonHeight);
                horizontalButtons[i][j].setLayoutY(j * buttonWidth + j * buttonHeight);

                final int finalI = i;
                final int finalJ = j;

                horizontalButtons[i][j].setOnAction(value -> {
                    if (!View.isFull(horizontalButtons[finalI][finalJ])) {
                        horizontalButtons[finalI][finalJ].getStyleClass().add((isCyanTurn ? "cyan" : "magenta"));
                        Model.updateTable(cyanScoreText, magentaScoreText, text, squares, horizontalButtons,
                                verticalButtons, finalI, finalJ, "horizontal");
                        if (cyanScore + magentaScore == 49) {
                            saveHistory();
                        }
                    } else {
                        System.out.println("This line is already colored.");
                    }
                });

                group.getChildren().add(horizontalButtons[i][j]);
            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 7; j++) {
                verticalButtons[i][j] = new Button();
                verticalButtons[i][j].setPadding(new Insets(0));
                verticalButtons[i][j].setPrefSize(buttonHeight, buttonWidth);
                verticalButtons[i][j].setLayoutX(i * buttonWidth + i * buttonHeight);
                verticalButtons[i][j].setLayoutY(j * buttonWidth + j * buttonHeight + buttonHeight);

                final int finalI = i;
                final int finalJ = j;

                verticalButtons[i][j].setOnAction(value -> {
                    if (!View.isFull(verticalButtons[finalI][finalJ])) {
                        verticalButtons[finalI][finalJ].getStyleClass().add(isCyanTurn ? "cyan" : "magenta");
                        Model.updateTable(cyanScoreText, magentaScoreText, text, squares, horizontalButtons,
                                verticalButtons, finalI, finalJ, "vertical");
                        if (cyanScore + magentaScore == 49) {
                            saveHistory();
                        }
                    } else {
                        System.out.println("This line is already colored.");
                    }
                });

                group.getChildren().add(verticalButtons[i][j]);

            }
        }

        GridPane gameStats = new GridPane();
        int topMargin = 7 * buttonWidth + (8 + 1) * buttonHeight;
        gameStats.setLayoutY(topMargin);

        text.getStyleClass().add("turn-text");

        gameStats.add(text, 0, 0);
        gameStats.add(cyanScoreText, 0, 1);
        gameStats.add(magentaScoreText, 0, 2);

        Scene scene = new Scene(startGame ? group : startButton, 600, 660);
        group.getChildren().add(gameStats);

        startButton.setOnAction(value -> {
            startGame = true;
            primaryStage.getScene().setRoot(startGame ? group : startButton);
        });

        scene.getStylesheets().add("./style/style.css");
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}