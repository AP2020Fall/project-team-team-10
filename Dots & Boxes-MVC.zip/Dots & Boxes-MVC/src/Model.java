
import javafx.scene.control.Button;

import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class Model {
    public static void updateTable(Text cyanScoreText, Text magentaScoreText, Text text, Rectangle[][] squares,
            Button[][] horizontalButtons, Button[][] verticalButtons, int i, int j, String direction) {
        boolean hasReward = false;

        if (direction == "vertical") {
            if (i != 7) {
                if (View.isFull(verticalButtons[i + 1][j]) && View.isFull(horizontalButtons[i][j])
                        && View.isFull(horizontalButtons[i][j + 1])) {
                    squares[i][j].getStyleClass().add((Controller.isCyanTurn ? "cyan" : "magenta"));
                    if (Controller.isCyanTurn) {
                        Controller.cyanScore++;
                    } else {
                        Controller.magentaScore++;
                    }
                    hasReward = true;
                }
            }

            if (i != 0) {
                if (View.isFull(verticalButtons[i - 1][j]) && View.isFull(horizontalButtons[i - 1][j])
                        && View.isFull(horizontalButtons[i - 1][j + 1])) {
                    squares[i - 1][j].getStyleClass().add((Controller.isCyanTurn ? "cyan" : "magenta"));
                    if (Controller.isCyanTurn) {
                        Controller.cyanScore++;
                    } else {
                        Controller.magentaScore++;
                    }
                    hasReward = true;
                }
            }

        }
        if (direction == "horizontal") {
            if (j != 0) {
                if (View.isFull(horizontalButtons[i][j - 1]) && View.isFull(verticalButtons[i][j - 1])
                        && View.isFull(verticalButtons[i + 1][j - 1])) {
                    squares[i][j - 1].getStyleClass().add((Controller.isCyanTurn ? "cyan" : "magenta"));
                    if (Controller.isCyanTurn) {
                        Controller.cyanScore++;
                    } else {
                        Controller.magentaScore++;
                    }
                    hasReward = true;
                }
            }

            if (j != 7) {
                if (View.isFull(horizontalButtons[i][j + 1]) && View.isFull(verticalButtons[i][j])
                        && View.isFull(verticalButtons[i + 1][j])) {
                    squares[i][j].getStyleClass().add((Controller.isCyanTurn ? "cyan" : "magenta"));
                    if (Controller.isCyanTurn) {
                        Controller.cyanScore++;
                    } else {
                        Controller.magentaScore++;
                    }
                    hasReward = true;
                }
            }
        }

        if (hasReward) {
        } else {
            Controller.isCyanTurn = !Controller.isCyanTurn;
            text.setText("It's " + (Controller.isCyanTurn ? "Cyan" : "Magenta") + " turn");
        }

        cyanScoreText.setText("Cyan : " + Controller.cyanScore);
        magentaScoreText.setText("Magenta : " + Controller.magentaScore);
    }

}
