import javafx.scene.control.Button;

public class View {
    public static boolean isFull(Button button) {
        return (button.getStyleClass().contains("magenta") || button.getStyleClass().contains("cyan"));
    }
}
