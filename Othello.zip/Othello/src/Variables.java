public class Variables {
    public static boolean itsWhiteTurn = true;
}