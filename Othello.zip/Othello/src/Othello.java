import java.util.Arrays;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Othello extends Application {
    public static boolean isWhiteTurn = false;
    public static int whiteScore = 2;
    public static int blackScore = 2;
    boolean startGame = false;

    static void handleClick(int i, int j, Button[][] buttons, Text text, Text whiteScoreText, Text blackScoreText,
            Text gameOverText) {

        String color = isWhiteTurn ? "white" : "black";
        String oppositeColor = color == "white" ? "black" : "white";

        int deadEnds = 0;
        int rowStep = 1;
        int rowIndex = i + rowStep;

        Boolean isAccepted = false;

        // row update
        while (deadEnds != 2) {
            if (rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][j], oppositeColor)) {
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                    while (hasColor(buttons[rowIndex][j], oppositeColor)) {
                        rowIndex += rowStep;
                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][j], color)) {
                        rowIndex -= rowStep;
                        while (rowOrder) {
                            placeDisk(buttons[rowIndex][j], color);
                            rowIndex -= rowStep;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            rowStep *= -1;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // column update
        deadEnds = 0;
        int columnStep = 1;
        int columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0) {
                if (hasColor(buttons[i][columnIndex], oppositeColor)) {
                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    while (hasColor(buttons[i][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[i][columnIndex], color)) {
                        columnIndex -= columnStep;
                        while (columnOrder) {
                            placeDisk(buttons[i][columnIndex], color);
                            columnIndex -= columnStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            columnIndex = j + columnStep;
            deadEnds++;
        }

        // diameter uphill update
        deadEnds = 0;
        rowStep = 1;
        rowIndex = i + rowStep;
        columnStep = -1;
        columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0 && rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {

                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;

                    while (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        rowIndex += rowStep;

                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }

                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][columnIndex], color)) {
                        columnIndex -= columnStep;
                        rowIndex -= rowStep;
                        while (columnOrder && rowOrder) {
                            placeDisk(buttons[rowIndex][columnIndex], color);
                            columnIndex -= columnStep;
                            rowIndex -= rowStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            rowStep *= -1;
            columnIndex = j + columnStep;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // diameter downhill update
        deadEnds = 0;
        rowStep = 1;
        rowIndex = i + rowStep;
        columnStep = 1;
        columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0 && rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {

                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;

                    while (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        rowIndex += rowStep;
                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }

                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][columnIndex], color)) {
                        columnIndex -= columnStep;
                        rowIndex -= rowStep;
                        while (columnOrder && rowOrder) {
                            placeDisk(buttons[rowIndex][columnIndex], color);
                            columnIndex -= columnStep;
                            rowIndex -= rowStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            rowStep *= -1;
            columnIndex = j + columnStep;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // change turn
        if (isAccepted) {
            isWhiteTurn = !isWhiteTurn;
            text.setText("It's " + (isWhiteTurn ? "White's" : "Blacks") + " turn");

            int whiteScore = 0;
            int blackScore = 0;

            for (int xx = 0; xx < 8; xx++) {
                for (int yy = 0; yy < 8; yy++) {
                    if (hasColor(buttons[xx][yy], "white")) {
                        whiteScore++;
                    } else {
                        if (hasColor(buttons[xx][yy], "black")) {
                            blackScore++;
                        }
                    }

                }
            }

            if (whiteScore + blackScore == 64) {
                if (whiteScore > blackScore) {
                    gameOverText.setText("Game Over! White has won.");
                } else {
                    if (whiteScore < blackScore) {
                        gameOverText.setText("Game Over! Black has won.");
                    } else {
                        gameOverText.setText("Game Over! equal win.");
                    }
                }
            }

            whiteScoreText.setText("White : " + whiteScore);
            blackScoreText.setText("Black : " + blackScore);
        }
    }

    static boolean hasColor(Button button, String color) {
        return (button.getStyleClass().contains(color));
    }

    static GridPane renderTable(Text text, Text whiteScoreText, Text blackScoreText, Text gameOverText) {
        Button[][] buttons = new Button[8][8];

        GridPane gridPane = new GridPane();

        gridPane.setPadding(new Insets(8, 8, 8, 8));
        gridPane.setVgap(8);
        gridPane.setHgap(8);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                buttons[i][j] = new Button();
                gridPane.add(buttons[i][j], i, j);

                // final Button button = buttons[i][j];
                final int finalI = i;
                final int finalJ = j;

                buttons[i][j].setOnAction(value -> {
                    if (!(hasColor(buttons[finalI][finalJ], "white") || hasColor(buttons[finalI][finalJ], "black"))) {
                        handleClick(finalI, finalJ, buttons, text, whiteScoreText, blackScoreText, gameOverText);
                    } else {
                        System.out.println("Slot is full");
                    }
                });
                buttons[i][j].setPrefWidth(57);
                buttons[i][j].setPrefHeight(57);
            }
        }

        placeDisk(buttons[4][4], "white");
        placeDisk(buttons[3][3], "white");
        placeDisk(buttons[4][3], "black");
        placeDisk(buttons[3][4], "black");

        return gridPane;
    }

    static void placeDisk(Button button, String color) {
        button.getStyleClass().remove("white");
        button.getStyleClass().remove("black");
        if (color == "white") {
            button.getStyleClass().add("white");
        }
        if (color == "black") {
            button.getStyleClass().add("black");
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Othello");

        Button startButton = new Button("Start");

        Text text = new Text("It's " + (isWhiteTurn ? "White's" : "Blacks") + " turn");
        Text gameOverText = new Text();

        Text whiteScoreText = new Text("White : " + whiteScore);
        Text blackScoreText = new Text("Black : " + blackScore);

        text.setText("It's " + (isWhiteTurn ? "White's" : "Blacks") + " turn");

        GridPane gameGrid = renderTable(text, whiteScoreText, blackScoreText, gameOverText);

        GridPane statsGrid = new GridPane();
        GridPane groupGrid = new GridPane();

        text.getStyleClass().add("turn-text");

        statsGrid.setPadding(new Insets(0, 8, 8, 8));

        statsGrid.add(text, 0, 0);
        statsGrid.add(whiteScoreText, 0, 1);
        statsGrid.add(blackScoreText, 0, 2);
        statsGrid.add(gameOverText, 0, 3);

        groupGrid.add(gameGrid, 0, 0);
        groupGrid.add(statsGrid, 0, 1);

        Scene scene = new Scene(startGame ? groupGrid : startButton, 528, 600);

        startButton.setOnAction(value -> {
            startGame = true;
            primaryStage.getScene().setRoot(startGame ? groupGrid : startButton);
        });

        scene.getStylesheets().add("./style/style.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);

    }
}