import javafx.scene.control.Button;
import javafx.scene.text.Text;

class Model {

    public static boolean isWhiteTurn = false;
    public static int whiteScore = 2;
    public static int blackScore = 2;
    static boolean startGame = false;

    public static boolean hasColor(Button button, String color) {
        return (button.getStyleClass().contains(color));
    }

    public static void handleClick(int i, int j, Button[][] buttons, Text text, Text whiteScoreText,
            Text blackScoreText, Text gameOverText) {

        String color = isWhiteTurn ? "white" : "black";
        String oppositeColor = color == "white" ? "black" : "white";

        int deadEnds = 0;
        int rowStep = 1;
        int rowIndex = i + rowStep;

        Boolean isAccepted = false;

        // row update
        while (deadEnds != 2) {
            if (rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][j], oppositeColor)) {
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                    while (hasColor(buttons[rowIndex][j], oppositeColor)) {
                        rowIndex += rowStep;
                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][j], color)) {
                        rowIndex -= rowStep;
                        while (rowOrder) {
                            View.placeDisk(buttons[rowIndex][j], color);
                            rowIndex -= rowStep;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            rowStep *= -1;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // column update
        deadEnds = 0;
        int columnStep = 1;
        int columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0) {
                if (hasColor(buttons[i][columnIndex], oppositeColor)) {
                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    while (hasColor(buttons[i][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[i][columnIndex], color)) {
                        columnIndex -= columnStep;
                        while (columnOrder) {
                            View.placeDisk(buttons[i][columnIndex], color);
                            columnIndex -= columnStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            columnIndex = j + columnStep;
            deadEnds++;
        }

        // diameter uphill update
        deadEnds = 0;
        rowStep = 1;
        rowIndex = i + rowStep;
        columnStep = -1;
        columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0 && rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {

                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;

                    while (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        rowIndex += rowStep;

                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }

                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][columnIndex], color)) {
                        columnIndex -= columnStep;
                        rowIndex -= rowStep;
                        while (columnOrder && rowOrder) {
                            View.placeDisk(buttons[rowIndex][columnIndex], color);
                            columnIndex -= columnStep;
                            rowIndex -= rowStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            rowStep *= -1;
            columnIndex = j + columnStep;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // diameter downhill update
        deadEnds = 0;
        rowStep = 1;
        rowIndex = i + rowStep;
        columnStep = 1;
        columnIndex = j + columnStep;

        while (deadEnds != 2) {
            if (columnIndex <= 7 && columnIndex >= 0 && rowIndex <= 7 && rowIndex >= 0) {
                if (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {

                    Boolean columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                    Boolean rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;

                    while (hasColor(buttons[rowIndex][columnIndex], oppositeColor)) {
                        columnIndex += columnStep;
                        rowIndex += rowStep;
                        if (rowIndex == 8) {
                            rowIndex = 7;
                            break;
                        }
                        if (rowIndex == -1) {
                            rowIndex = 0;
                            break;
                        }

                        if (columnIndex == 8) {
                            columnIndex = 7;
                            break;
                        }
                        if (columnIndex == -1) {
                            columnIndex = 0;
                            break;
                        }
                    }
                    if (hasColor(buttons[rowIndex][columnIndex], color)) {
                        columnIndex -= columnStep;
                        rowIndex -= rowStep;
                        while (columnOrder && rowOrder) {
                            View.placeDisk(buttons[rowIndex][columnIndex], color);
                            columnIndex -= columnStep;
                            rowIndex -= rowStep;
                            columnOrder = columnStep == 1 ? columnIndex >= j : columnIndex <= j;
                            rowOrder = rowStep == 1 ? rowIndex >= i : rowIndex <= i;
                        }
                        isAccepted = true;
                    }
                }
            }
            columnStep *= -1;
            rowStep *= -1;
            columnIndex = j + columnStep;
            rowIndex = i + rowStep;
            deadEnds++;
        }

        // change turn
        if (isAccepted) {
            isWhiteTurn = !isWhiteTurn;
            text.setText("It's " + (isWhiteTurn ? "White's" : "Blacks") + " turn");

            int whiteScore = 0;
            int blackScore = 0;

            for (int xx = 0; xx < 8; xx++) {
                for (int yy = 0; yy < 8; yy++) {
                    if (hasColor(buttons[xx][yy], "white")) {
                        whiteScore++;
                    } else {
                        if (hasColor(buttons[xx][yy], "black")) {
                            blackScore++;
                        }
                    }

                }
            }

            if (whiteScore + blackScore == 64) {
                if (whiteScore > blackScore) {
                    gameOverText.setText("Game Over! White has won.");
                } else {
                    if (whiteScore < blackScore) {
                        gameOverText.setText("Game Over! Black has won.");
                    } else {
                        gameOverText.setText("Game Over! equal win.");
                    }
                }
            }

            whiteScoreText.setText("White : " + whiteScore);
            blackScoreText.setText("Black : " + blackScore);
        }
    }

}
