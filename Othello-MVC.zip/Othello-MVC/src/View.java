import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class View {
    static GridPane renderTable(Text text, Text whiteScoreText, Text blackScoreText, Text gameOverText) {

        Button[][] buttons = new Button[8][8];

        GridPane gridPane = new GridPane();

        gridPane.setPadding(new Insets(8, 8, 8, 8));
        gridPane.setVgap(8);
        gridPane.setHgap(8);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                buttons[i][j] = new Button();
                gridPane.add(buttons[i][j], i, j);

                // final Button button = buttons[i][j];
                final int finalI = i;
                final int finalJ = j;

                buttons[i][j].setOnAction(value -> {
                    if (!(Model.hasColor(buttons[finalI][finalJ], "white")
                            || Model.hasColor(buttons[finalI][finalJ], "black"))) {
                        Model.handleClick(finalI, finalJ, buttons, text, whiteScoreText, blackScoreText, gameOverText);
                    } else {
                        System.out.println("Slot is full");
                    }
                });
                buttons[i][j].setPrefWidth(57);
                buttons[i][j].setPrefHeight(57);
            }
        }

        placeDisk(buttons[4][4], "white");
        placeDisk(buttons[3][3], "white");
        placeDisk(buttons[4][3], "black");
        placeDisk(buttons[3][4], "black");

        return gridPane;
    }

    static void placeDisk(Button button, String color) {
        button.getStyleClass().remove("white");
        button.getStyleClass().remove("black");
        if (color == "white") {
            button.getStyleClass().add("white");
        }
        if (color == "black") {
            button.getStyleClass().add("black");
        }
    }
}
