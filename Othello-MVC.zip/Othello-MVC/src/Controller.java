import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Controller extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Othello");

        Button startButton = new Button("Start");

        Text text = new Text("It's " + (Model.isWhiteTurn ? "White's" : "Blacks") + " turn");
        Text gameOverText = new Text();

        Text whiteScoreText = new Text("White : " + Model.whiteScore);
        Text blackScoreText = new Text("Black : " + Model.blackScore);

        text.setText("It's " + (Model.isWhiteTurn ? "White's" : "Blacks") + " turn");

        GridPane gameGrid = View.renderTable(text, whiteScoreText, blackScoreText, gameOverText);

        GridPane statsGrid = new GridPane();
        GridPane groupGrid = new GridPane();

        text.getStyleClass().add("turn-text");

        statsGrid.setPadding(new Insets(0, 8, 8, 8));

        statsGrid.add(text, 0, 0);
        statsGrid.add(whiteScoreText, 0, 1);
        statsGrid.add(blackScoreText, 0, 2);
        statsGrid.add(gameOverText, 0, 3);

        groupGrid.add(gameGrid, 0, 0);
        groupGrid.add(statsGrid, 0, 1);

        Scene scene = new Scene(Model.startGame ? groupGrid : startButton, 528, 600);

        startButton.setOnAction(value -> {
            Model.startGame = true;
            primaryStage.getScene().setRoot(Model.startGame ? groupGrid : startButton);
        });

        scene.getStylesheets().add("./style/style.css");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);

    }
}
